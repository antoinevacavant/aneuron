import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class aneuron extends PApplet {

/*****************************************************************************
Copyright (c) 2021 Antoine Vacavant

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*****************************************************************************/

/*****************************************************************************
PApplet aneuron
---------------
Draw the neuron, and buttons to change vars
Push "Compute" button to simulate neuron's behavior
*****************************************************************************/

// Important vars and inits 
float w_1 = 0.5f, w_2 = 0.2f, w_3 = 0.3f;

float x_1 = 2, x_2 = 4, x_3 = 1;

float sum = 0.f;

float theta = 0.1f;

float a = 0.f;

float y = 0.f;

// For updating in gui 
float limit_x = 10;
float limit_theta = 5;
float step_x = 0.1f;
float step_theta = 0.1f;
float step_w = 0.05f;

PFont myfont;

// All buttons 
SimpleButton btnx1_plus, btnx2_plus, btnx3_plus;
SimpleButton btnx1_minus, btnx2_minus, btnx3_minus;

SimpleButton btnw1_plus, btnw2_plus, btnw3_plus;
SimpleButton btnw1_minus, btnw2_minus, btnw3_minus;

SimpleButton btntheta_plus, btntheta_minus;

SimpleButton btn_compute;

SimpleButton btn_threshold;
SimpleButton btn_sigmoid;
SimpleButton btn_tanh;

// Thumbnails of activation funcs 
PImage img_threshold;
PImage img_sigmoid;
PImage img_tanh;

// Setup func.
public void setup() {
  
  background(255);
  frameRate(30);
  
  myfont = loadFont("Consolas-48.vlw");
  textFont(myfont);

  // Buttons for x_i 
  btnx1_plus= new SimpleButton(width/2-400, height/2-200, 40, 40);
  btnx1_plus.setText("+");
  btnx1_plus.setTextSize(30);

  btnx2_plus= new SimpleButton(width/2-400, height/2, 40, 40);
  btnx2_plus.setText("+");
  btnx2_plus.setTextSize(30);

  btnx3_plus= new SimpleButton(width/2-400, height/2+200, 40, 40);
  btnx3_plus.setText("+");
  btnx3_plus.setTextSize(30);

  btnx1_minus= new SimpleButton(width/2-440, height/2-200, 40, 40);
  btnx1_minus.setText("-");
  btnx1_minus.setTextSize(30);

  btnx2_minus= new SimpleButton(width/2-440, height/2, 40, 40);
  btnx2_minus.setText("-");
  btnx2_minus.setTextSize(30);

  btnx3_minus= new SimpleButton(width/2-440, height/2+200, 40, 40);
  btnx3_minus.setText("-");
  btnx3_minus.setTextSize(30);

  // Buttons for w_i 
  btnw1_plus= new SimpleButton(width/2-200, height/2-200, 40, 40);
  btnw1_plus.setText("+");
  btnw1_plus.setTextSize(30);

  btnw2_plus= new SimpleButton(width/2-200, height/2, 40, 40);
  btnw2_plus.setText("+");
  btnw2_plus.setTextSize(30);

  btnw3_plus= new SimpleButton(width/2-200, height/2+200, 40, 40);
  btnw3_plus.setText("+");
  btnw3_plus.setTextSize(30);

  btnw1_minus= new SimpleButton(width/2-240, height/2-200, 40, 40);
  btnw1_minus.setText("-");
  btnw1_minus.setTextSize(30);

  btnw2_minus= new SimpleButton(width/2-240, height/2, 40, 40);
  btnw2_minus.setText("-");
  btnw2_minus.setTextSize(30);

  btnw3_minus= new SimpleButton(width/2-240, height/2+200, 40, 40);
  btnw3_minus.setText("-");
  btnw3_minus.setTextSize(30);

  // Buttons for bias 
  btntheta_plus= new SimpleButton(width/2+60, height/2-40, 40, 40);
  btntheta_plus.setText("+");
  btntheta_plus.setTextSize(30);

  btntheta_minus= new SimpleButton(width/2+20, height/2-40, 40, 40);
  btntheta_minus.setText("-");
  btntheta_minus.setTextSize(30);

  // Button for calculation 
  btn_compute= new SimpleButton(width/2, height/2+400, 200, 70);
  btn_compute.setText("compute");
  btn_compute.setTextSize(35);

  // Buttons for activations 
  btn_threshold= new SimpleButton(width/2+280, height/2-400, 200, 70);
  btn_threshold.setToggleButton(true);
  btn_threshold.toggle();
  btn_threshold.setText("threshold");
  btn_threshold.setTextSize(35);

  btn_sigmoid= new SimpleButton(width/2+280, height/2-300, 200, 70);
  btn_sigmoid.setToggleButton(true);
  btn_sigmoid.setText("sigmoid");
  btn_sigmoid.setTextSize(35);

  btn_tanh= new SimpleButton(width/2+280, height/2-200, 200, 70);
  btn_tanh.setToggleButton(true);
  btn_tanh.setText("tanh");
  btn_tanh.setTextSize(35);

  // Images for activations 
  img_threshold = loadImage("threshold.png");
  img_sigmoid = loadImage("sigmoid.png");
  img_tanh = loadImage("tanh.png");
}

// Draw func.
public void draw() {

  background(255);
  noStroke();
  smooth();

  // 2 half-ellipses 
  fill(255, 128, 33, 122.5f);
  arc(width/2-20, height/2, 300, 200, HALF_PI, 3*HALF_PI);

  fill(251, 65, 36, 122.5f);    
  arc(width/2+100, height/2, 300, 200, -HALF_PI, HALF_PI);

  // Texts 
  fill(0);
  textFont(myfont, 30);
  textSize(30);
  textAlign(CENTER, CENTER);
  text(x_1, width/2-420, height/2-150);
  text("x_1", width/2-420, height/2-250);

  text(x_2, width/2-420, height/2+50);
  text("x_2", width/2-420, height/2-50);

  text(x_3, width/2-420, height/2+250);
  text("x_3", width/2-420, height/2+150);

  text(w_1, width/2-220, height/2-150);
  text("w_1", width/2-220, height/2-250);

  text(w_2, width/2-220, height/2+50);
  text("w_2", width/2-220, height/2-50);

  text(w_3, width/2-220, height/2+250);
  text("w_3", width/2-220, height/2+150);

  text(sum, width/2-80, height/2);

  text(theta, width/2+40, height/2+20);
  text("bias", width/2+40, height/2-100);

  text(a, width/2+160, height/2);

  text("y", width/2+400, height/2+40);
  text(y, width/2+400, height/2-40);

  // Lines 
  stroke(78, 103, 200);
  strokeWeight(10);
  line(width/2-350, height/2-180, width/2-200, height/2-100);
  line(width/2-350, height/2, width/2-280, height/2);
  line(width/2-350, height/2+180, width/2-200, height/2+100);

  stroke(94, 204, 243);
  line(width/2, height/2+60, width/2+80, height/2+60);

  stroke(167, 234, 82);
  line(width/2+280, height/2, width/2+360, height/2);

  // Draw all buttons 
  btnx1_plus.draw(this);
  btnx2_plus.draw(this);
  btnx3_plus.draw(this);
  btnx1_minus.draw(this);
  btnx2_minus.draw(this);
  btnx3_minus.draw(this);

  btnw1_plus.draw(this);
  btnw2_plus.draw(this);
  btnw3_plus.draw(this);
  btnw1_minus.draw(this);
  btnw2_minus.draw(this);
  btnw3_minus.draw(this);

  btntheta_minus.draw(this);
  btntheta_plus.draw(this);

  btn_compute.draw(this);

  btn_threshold.draw(this);
  btn_sigmoid.draw(this);
  btn_tanh.draw(this);

  // Interacts buttons for x_i
  if (btnx1_plus.over(mouseX, mouseY) && mousePressed) {
    if (x_1 < limit_x)
      x_1 += step_x;
    btnx1_plus.click(true);
  } else {
    btnx1_plus.click(false);
  }
  if (btnx2_plus.over(mouseX, mouseY) && mousePressed) {
    if (x_2 < limit_x)
      x_2 += step_x;
    btnx2_plus.click(true);
  } else {
    btnx2_plus.click(false);
  }
  if (btnx3_plus.over(mouseX, mouseY) && mousePressed) {
    if (x_3 < limit_x)
      x_3 += step_x;
    btnx3_plus.click(true);
  } else {
    btnx3_plus.click(false);
  }


  if (btnx1_minus.over(mouseX, mouseY) && mousePressed) {
    if (x_1 > 0.001f)
      x_1 -= step_x;
    x_1 = abs(x_1);
    btnx1_minus.click(true);
  } else {
    btnx1_minus.click(false);
  }
  if (btnx2_minus.over(mouseX, mouseY) && mousePressed) {
    if (x_2 > 0.001f)
      x_2 -=  step_x;
    x_2 = abs(x_2);
    btnx2_minus.click(true);
  } else {
    btnx2_minus.click(false);
  }
  if (btnx3_minus.over(mouseX, mouseY) && mousePressed) {
    if (x_3 > 0.001f)
      x_3 -= step_x;
    x_3 = abs(x_3);
    btnx3_minus.click(true);
  } else {
    btnx3_minus.click(false);
  }

  // Interacts with w_i
  if (btnw1_plus.over(mouseX, mouseY) && mousePressed) {
    if (w_1 < 1)
      w_1 += step_w;
    btnw1_plus.click(true);
  } else {
    btnw1_plus.click(false);
  }
  if (btnw2_plus.over(mouseX, mouseY) && mousePressed) {
    if (w_2 < 1)
      w_2 += step_w;
    btnw2_plus.click(true);
  } else {
    btnw2_plus.click(false);
  }
  if (btnw3_plus.over(mouseX, mouseY) && mousePressed) {
    if (w_3 < 1)
      w_3 += step_w;
    btnw3_plus.click(true);
  } else {
    btnw3_plus.click(false);
  }


  if (btnw1_minus.over(mouseX, mouseY) && mousePressed) {
    if (w_1 > 0.001f)
      w_1 -= step_w;
    w_1 = abs(w_1);
    btnw1_minus.click(true);
  } else {
    btnw1_minus.click(false);
  }
  if (btnw2_minus.over(mouseX, mouseY) && mousePressed) {
    if (w_2 > 0.001f)
      w_2 -=  step_w;
    btnw2_minus.click(true);
  } else {
    btnw2_minus.click(false);
  }
  if (btnw3_minus.over(mouseX, mouseY) && mousePressed) {
    if (w_3 > 0.001f)
      w_3 -= step_w;
    btnw3_minus.click(true);
  } else {
    btnw3_minus.click(false);
  }

  if (btn_compute.over(mouseX, mouseY) && mousePressed) {
    compute();
  }

  // Interacts with bias 
  if (btntheta_minus.over(mouseX, mouseY) && mousePressed) {
    if (theta > -limit_theta+0.001f)
      theta -= step_theta;
    btntheta_minus.click(true);
  } else {
    btntheta_minus.click(false);
  }
  if (btntheta_plus.over(mouseX, mouseY) && mousePressed) {
    if (theta < limit_theta-0.001f)
      theta += step_theta;
    btntheta_plus.click(true);
  } else {
    btntheta_plus.click(false);
  }

  // Interacts with activation buttons 
  if (btn_threshold.over(mouseX, mouseY) && mousePressed && !btn_threshold.isOn()) {
    btn_threshold.toggle();
    if (btn_sigmoid.isOn()) {
      btn_sigmoid.toggle();
    }
    if (btn_tanh.isOn()) {
      btn_tanh.toggle();
    }
  }
  if (btn_sigmoid.over(mouseX, mouseY) && mousePressed && !btn_sigmoid.isOn()) {
    btn_sigmoid.toggle();
    if (btn_threshold.isOn()) {
      btn_threshold.toggle();
    }
    if (btn_tanh.isOn()) {
      btn_tanh.toggle();
    }
  }
  if (btn_tanh.over(mouseX, mouseY) && mousePressed && !btn_tanh.isOn()) {
    btn_tanh.toggle();
    if (btn_threshold.isOn()) {
      btn_threshold.toggle();
    }
    if (btn_sigmoid.isOn()) {
      btn_sigmoid.toggle();
    }
  }

  // Display images 
  image(img_threshold, width/2+80, height/2-435, 80, 80);
  image(img_sigmoid, width/2+80, height/2-335, 80, 80);
  image(img_tanh, width/2+80, height/2-235, 80, 80);

  // Display equation 
  textSize(20);
  textAlign(LEFT);
  fill(100);
  String str = "output: activfunc( w_1 * x_1  + w_2 * x_2  + w_3 * x_3  - (bias) ) = y";
  text(str, width/2-400, height/2 + 300);
   
  String str_eqn = "        ";
  if (btn_threshold.isOn()) {
    str_eqn = str_eqn + "threshold( ";
  }
  if (btn_sigmoid.isOn()) {
    str_eqn = str_eqn + "  sigmoid( ";
  }
  if (btn_tanh.isOn()) {
    str_eqn = str_eqn + "     tanh( ";
  }
  
  str_eqn = str_eqn + nf(w_1, 1, 1) + " * " + nf(x_1, 2, 1) + " + ";
  str_eqn = str_eqn + nf(w_2, 1, 1) + " * " + nf(x_2, 2, 1) + " + ";
  str_eqn = str_eqn + nf(w_3, 1, 1) + " * " + nf(x_3, 2, 1) + " - ";
  str_eqn = str_eqn + "(" + nfs(theta, 1, 1) + ")" + " ) = " + nf(y, 1, 3);
  text(str_eqn, width/2-400, height/2 + 340);
}

// Compute values with inputs 
public void compute() {
  sum = x_1*w_1 + x_2*w_2 + x_3*w_3; 
  a = sum - theta;
  if (btn_threshold.isOn()) {
    y = func_step(a);
  }
  if (btn_sigmoid.isOn()) {
    y = func_sigmoid(a);
  }
  if (btn_tanh.isOn()) {
    y = func_tanh(a);
  }
}

// Activation func: thresholding 
public float func_step(float x) {
  if (x < 0) {
    return 0;
  } else {
    return 1;
  }
}

// Activation func: sigmoid 
public float func_sigmoid(float x) {
  return 1.f / (1+exp(-x));
}

// Activation func: tanh 
public float func_tanh(float x) {
  return 1 -  2.f/(exp(2*x)+1);
}
/*****************************************************************************
Copyright (c) 2021 Antoine Vacavant

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*****************************************************************************/

/*****************************************************************************
SimpleButton
------------
Class to add and interact with buttons
Not perfect, but works well ;)
*****************************************************************************/

public class SimpleButton {

  // Position and size
  protected int _iPosX;
  protected int _iPosY;
  protected int _iLenX;
  protected int _iLenY;

  // Is there any object on the button?
  protected boolean _bOver; 

  // Is the mouse clicking?
  private boolean _bClicked;

  // Is it a toggle button?
  private boolean _bToggleButton;
  private boolean _bOn;

  // Is this enabled?
  private boolean _bEnabled;

  // Colors and graphical props 
  protected int _colStroke;
  protected int _iStrokeAlpha;
  protected int _colStrokeOver;
  protected int _colStrokeClicked;
  protected int _colStrokeDisabled;
  protected int _iStrokeW;
  protected int _colFill;
  protected int _iFillAlpha;
  protected int _colFillOver;
  protected int _colFillClicked;
  protected int _colFillDisabled;
  protected int _iRad;

  // Is there a shadow?
  protected boolean _bShadow;

  // Text inside
  private String _sText;
  private int _iTextSize;
  private int _colText;
  private int _colTextOver;
  private int _colTextClicked;
  private int _colTextDisabled;

  // When moving the button, can shift w.r.t. mouse pos
  protected int _iShiftX;
  protected int _iShiftY;

  // Constructor with pos & size
  public SimpleButton(int iX, int iY, int iLx, int iLy) {
    _iPosX= iX;
    _iPosY= iY;
    _iLenX= iLx;
    _iLenY= iLy;
    resetDraw();
  }

  // Default constructor
  public SimpleButton() {
    resetPos(); 
    resetDraw();
  }

  // Position at top left
  public void resetPos() {
    _iPosX=25;
    _iPosY=15;
    _iLenX=50;
    _iLenY=30;
  }

  // Get left, right, top, bottom borders 
  public int getLeft() {
    return _iPosX-_iLenX/2;
  }
  public int getRight() {
    return _iPosX+_iLenX/2;
  }
  public int getTop() {
    return _iPosY-_iLenY/2;
  }
  public int getBottom() {
    return _iPosY+_iLenY/2;
  }

  public int getLenX() {
    return _iLenX;
  }
  public int getLenY() {
    return _iLenY;
  }
  public int getPosX() {
    return _iPosX;
  }
  public int getPosY() {
    return _iPosY;
  }

  // Default props
  public void resetDraw() {
    _bOver= false;
    _bClicked= false;
    _bToggleButton= false;
    _bOn= false;
    _bEnabled= true;
    _bShadow= true;
    _colStroke= 0xff232931;
    _iStrokeAlpha= 255;
    _colStrokeOver= 0xffEEEEEE;
    _colStrokeClicked= 0xffEEEEEE;
    _colStrokeDisabled= 0xff888888;
    _iStrokeW= 2;
    _colFill= 0xff9AAFCB;
    _iFillAlpha= 255;
    _colFillOver= 0xff9AAFCB;
    _colFillClicked= 0xffEEEEEE;
    _colFillDisabled= 0xff222222;
    _colText= 0xff232931;
    _iRad= 7;
    _sText= "";
    _iTextSize= 12;
    _colText= 0xff111111;
    _colTextOver= 0xffEEEEEE;
    _colTextClicked= 0xff111111;
    _colTextDisabled= 0xff888888;
  }

  // Drawing func.
  public void draw(PApplet app) {        
    // Design
    if (app != null) {
      app.rectMode(CENTER);
      // Shadow first
      if (_bShadow) {
        int iShadowW=10;
        noStroke();
        for (int i=iShadowW; i>=0; i--) {
          app.fill(0,PApplet.parseInt(255.f*(1.f-PApplet.parseFloat(i)/PApplet.parseFloat(iShadowW))));
          app.rect(_iPosX, _iPosY+i, _iLenX, _iLenY, _iRad);
        } 
      }
      
      // The button
      if (!_bEnabled) {
        app.stroke(_colStrokeDisabled, _iStrokeAlpha);
        app.fill(_colFillDisabled, _iFillAlpha);
      } else {
        if (_bOver) {        
          app.stroke(_colStrokeOver, _iStrokeAlpha);
          app.fill(_colFillOver, _iFillAlpha);
          if (_bClicked || (_bToggleButton && _bOn)) {
            app.stroke(_colStrokeClicked, _iStrokeAlpha);
            app.fill(_colFillClicked, _iFillAlpha);
          }
        } else {
          if (_bToggleButton && _bOn) {
            app.stroke(_colStrokeClicked, _iStrokeAlpha);
            app.fill(_colFillClicked, _iFillAlpha);
          } else {
            app.stroke(_colStroke, _iStrokeAlpha);
            app.fill(_colFill, _iFillAlpha);
          }
        }
      }
      app.rectMode(CENTER);      
      app.strokeWeight(_iStrokeW);
      app.rect(_iPosX, _iPosY, _iLenX, _iLenY, _iRad);

      // Text   
      if (!_bEnabled) {
        app.fill(_colTextDisabled);
      } else {   
        if (_bOver) {        
          app.fill(_colTextOver);
          if (_bClicked || (_bToggleButton && _bOn)) {
            app.fill(_colTextClicked);
          }
        } else {
          if (_bToggleButton && _bOn) {
            app.fill(_colTextClicked);
          } else {
            app.fill(_colText);
          }
        }
      }
      app.textAlign(CENTER, CENTER);  
      app.textSize(_iTextSize);
      app.text(_sText, _iPosX, _iPosY);
    } // if (app != null)
  }

  // Move the button
  public void move(int iX, int iY) {
    _iPosX= iX+_iShiftX;
    _iPosY= iY+_iShiftY;
  }

  // Resize
  public void resize(int iLx, int iLy) {
    _iLenX= iLx;
    _iLenY= iLy;
  }

  // Change text inside
  public void setText(String sText) {
    _sText= sText;
  }

  // Change text size 
  public void setTextSize(int iSize) {
    _iTextSize= iSize;
  }

  // Is there any object over the button?
  public boolean over(int iX, int iY) {
    if (iX <= _iPosX+_iLenX/2 && iX >= _iPosX-_iLenX/2 && iY <= _iPosY+_iLenY/2 && iY >= _iPosY-_iLenY/2) {
      _bOver=true;
    } else {
      _bOver= false;
    }
    return _bOver;
  }

  // Click it
  public void click(boolean bClick) {
    if (_bEnabled) {
      _bClicked=bClick;
    }
  }

  // Init the button as a toggle button
  public void setToggleButton(boolean bToggle) {
    if (_bEnabled) {
      _bToggleButton= bToggle;
    }
  }

  // Toggle the button, for a toggle button only
  public void toggle() {
    if (_bToggleButton && _bEnabled) {
      _bOn= !_bOn;
    }
  }

  // For a toggle button, is it on?
  public boolean isOn() {
    return (_bToggleButton && _bOn);
  }

  // Is it clicked?
  public boolean isClicked() {
    return _bClicked;
  }

  // Enable/Disable
  public void enable(boolean bEnable) {
    _bEnabled= bEnable;
  }
  
  // Shift pos w.r.t. mouse for instance
  public void shift(int iX, int iY) {
    _iShiftX=_iPosX-iX;
    _iShiftY=_iPosY-iY; 
  }
}
  public void settings() {  size(1000, 1000); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "aneuron" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
